
# Dataset is in CSV format
Relative Time (seconds) | X Position (meters) | Y Position (meters) | WiFi RSSI 1 | WiFi RSSI 2 | WiFi RSSI 3 .....| BLE RSSI 1 | BLE RSSI 2| BLE RSSI 3 ....

WiFi RSSI, WiFi SQI and BLE RSSI from multiple APs
