# Dataset is in CSV format
Relative Time (seconds) | X Position (meters) | Y Position (meters) | BLE RSSI 1 | BLE RSSI 2 | BLE RSSI 3 .....

BLE RSSI only from multiple APs
