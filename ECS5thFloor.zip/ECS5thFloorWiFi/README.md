
# Dataset is in CSV format
Relative Time (seconds) | X Position (meters) | Y Position (meters) | WiFi RSSI 1 | WiFi RSSI 2 | WiFi RSSI 3 .....

WiFi RSSI and WiFi SQI from multiple APs
